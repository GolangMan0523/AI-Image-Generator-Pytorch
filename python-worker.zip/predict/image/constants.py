SIZE_LIST = range(256, 1537, 8)
