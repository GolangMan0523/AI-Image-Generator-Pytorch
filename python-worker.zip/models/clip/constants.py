CLIP_MODEL_ID = "openai/clip-vit-large-patch14"
CLIP_TOKEN_LENGTH_MAX = 77