#!/bin/bash

source venv/bin/activate
python main.py