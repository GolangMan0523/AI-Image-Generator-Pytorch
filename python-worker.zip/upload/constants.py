import os

S3_REGION = os.environ.get("S3_REGION")
S3_ENDPOINT_URL = os.environ.get("S3_ENDPOINT_URL")
S3_BUCKET_NAME_UPLOAD = os.environ.get("S3_BUCKET_NAME_UPLOAD")
S3_ACCESS_KEY_ID = os.environ.get("AWS_ACCESS_KEY_ID")
S3_SECRET_ACCESS_KEY = os.environ.get("AWS_SECRET_ACCESS_KEY")
